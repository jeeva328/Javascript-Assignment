let arr = [1,2,3,4,5,6,7,8,9,24,56,39];
let odd = arr.filter(el=>el%2!=0);
let oddSquares = arr.filter(el=>el%2!=0).map(el=>el**3);

console.log(odd);
console.log(oddSquares);